#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  1 12:03:45 2021

@author: bizzy
"""

import sys
import time
import datetime
import numpy as np
import pandas as pd

import pyupbit
from PyQt5.QtCore import QDate
from PyQt5.QtWidgets import QApplication, QWidget, QDesktopWidget, \
    QPushButton, QRadioButton, QLabel, QLineEdit, QDateEdit, QCheckBox, \
    QMessageBox, QInputDialog, \
    QGroupBox, QHBoxLayout, QVBoxLayout, QGridLayout


class MyApp(QWidget):

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        vbox = QVBoxLayout()
        vbox.addWidget(self.Groupbox_API())
        vbox.addWidget(self.Groupbox_Strategy())        
        vbox.addWidget(self.Groupbox_Trade())        
        vbox.addWidget(self.Groupbox_Backtest())        


        self.setLayout(vbox)
        # self.btn_Trade.clicked.connect(self.Trade)
        # self.btn_Backtest.clicked.connect(self.BackTest)

        # self.btn_Backtest.clicked.connect(self.BackTest)
        # self.SaveButton.clicked.connect(self.SaveData)
        # self.LoadButton.clicked.connect(self.LoadData)

        self.setWindowTitle('Upbit')
        self.setGeometry(300, 300, 400, 200)
        self.show()

    def Groupbox_API(self):
        groupbox = QGroupBox('API')
        grid = QGridLayout()

        lbl1 = QLabel()
        lbl2 = QLabel()

        self.qle1 = QLineEdit()
        self.qle2 = QLineEdit()

        self.SaveButton = QPushButton('Save Data')
        self.LoadButton = QPushButton('Load Data')


        grid.addWidget(lbl1, 0, 0)
        grid.addWidget(lbl2, 1, 0)
        grid.addWidget(self.SaveButton, 2, 0)
        grid.addWidget(self.LoadButton, 3, 0)

        grid.addWidget(self.qle1, 0, 1)
        grid.addWidget(self.qle2, 1, 1)

        groupbox.setLayout(grid)

        return groupbox

    def Groupbox_Strategy(self):
        groupbox = QGroupBox('Strategy')
        grid = QGridLayout()

        lbl1 = QLabel()
        lbl2 = QLabel()

        self.qle1 = QLineEdit()
        self.qle2 = QLineEdit()

        self.SaveButton = QPushButton('Save Data')
        self.LoadButton = QPushButton('Load Data')


        grid.addWidget(lbl1, 0, 0)
        grid.addWidget(lbl2, 1, 0)
        grid.addWidget(self.SaveButton, 2, 0)
        grid.addWidget(self.LoadButton, 3, 0)

        grid.addWidget(self.qle1, 0, 1)
        grid.addWidget(self.qle2, 1, 1)

        groupbox.setLayout(grid)

        return groupbox

    def Groupbox_Trade(self):
        groupbox = QGroupBox('Trade')
        grid = QGridLayout()

        lbl1 = QLabel()
        lbl2 = QLabel()

        self.qle1 = QLineEdit()
        self.qle2 = QLineEdit()

        self.SaveButton = QPushButton('Save Data')
        self.LoadButton = QPushButton('Load Data')


        grid.addWidget(lbl1, 0, 0)
        grid.addWidget(lbl2, 1, 0)
        grid.addWidget(self.SaveButton, 2, 0)
        grid.addWidget(self.LoadButton, 3, 0)

        grid.addWidget(self.qle1, 0, 1)
        grid.addWidget(self.qle2, 1, 1)

        groupbox.setLayout(grid)

        return groupbox

    def Groupbox_Backtest(self):
        groupbox = QGroupBox('Backtest')
        grid = QGridLayout()

        lbl1 = QLabel()
        lbl2 = QLabel()

        self.qle1 = QLineEdit()
        self.qle2 = QLineEdit()

        self.SaveButton = QPushButton('Save Data')
        self.LoadButton = QPushButton('Load Data')


        grid.addWidget(lbl1, 0, 0)
        grid.addWidget(lbl2, 1, 0)
        grid.addWidget(self.SaveButton, 2, 0)
        grid.addWidget(self.LoadButton, 3, 0)

        grid.addWidget(self.qle1, 0, 1)
        grid.addWidget(self.qle2, 1, 1)

        groupbox.setLayout(grid)

        return groupbox
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyApp()
    sys.exit(app.exec_())